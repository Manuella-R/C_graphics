import logging
import pandas as pd
import re
from collections import defaultdict
import json

# Import email generation function and other helper functions
from functions import create_email, is_valid_email, is_name_length_valid, check_email_exists

# Setup logging configuration
logging.basicConfig(filename='student_log.txt', level=logging.INFO)

# File path for the Excel file
file_path = r"C:\Users\rehem\Downloads\TestFiles.xlsx"

# Read the Excel file into a DataFrame
data = pd.read_excel(file_path)

logging.info(f"Loaded {len(data)} records from {file_path}")

# Initialize containers for storing email information and filtered lists
email_records = {}
students_with_special_chars = []
invalid_emails = []

male_students = []
female_students = []

# Process each student's record
for idx in range(len(data)):
    student_name = data.loc[idx, 'Student Name']
    logging.info(f"Processing student: {student_name}")

    # Check if name length is valid
    if not is_name_length_valid(student_name):
        logging.warning(f"Name length invalid: {student_name}")
        continue

    # Check if the email already exists for the student
    if student_name not in email_records:
        email_address = create_email(student_name)  # Call the email generator function
        if is_valid_email(email_address):
            email_records[student_name] = email_address
        else:
            invalid_emails.append(email_address)
    else:
        logging.warning(f"Duplicate entry detected for: {student_name}")

    # Detect names with special characters
    if re.search(r"[^a-zA-Z\-']", student_name):
        students_with_special_chars.append(student_name)

    # Print formatted output for each student
    output = f"Student Name: {student_name} - Email: {email_records.get(student_name, 'N/A')}"
    print(output)

    # Segregate students based on gender
    if data.loc[idx, 'Gender'] == 'M':
        male_students.append(student_name)
    elif data.loc[idx, 'Gender'] == 'F':
        female_students.append(student_name)

# Similarity check and filter (comparing names based on shared characters)
similarity_data = defaultdict(dict)

for male in male_students:
    for female in female_students:
        similarity_score = len(set(male) & set(female)) / max(len(male), len(female)) * 100
        similarity_data[male][female] = similarity_score

# Filter similarity results based on a threshold (e.g., 50% similarity)
filtered_similarity = {
    male: {female: score for female, score in female_dict.items() if score >= 50}
    for male, female_dict in similarity_data.items()
    if any(score >= 50 for score in female_dict.values())
}

# Save the filtered similarity matrix to a JSON file
with open("filtered_similarity.json", "w") as file:
    json.dump(filtered_similarity, file, indent=4)

# Log the count of male and female students
logging.info(f"Total male students: {len(male_students)}")
logging.info(f"Total female students: {len(female_students)}")
logging.info(f"Male student list: {male_students}")
logging.info(f"Female student list: {female_students}")

# Print male and female student lists
print("Male Students:")
print(male_students)

print("Female Students:")
print(female_students)

# Log students with special characters
if students_with_special_chars:
    logging.info(f"Students with special characters found: {students_with_special_chars}")

# Save the results into CSV files
pd.DataFrame({'Student Name': male_students}).to_csv(r'C:\Users\rehem\Downloads\cgraphics\male_students.csv', index=False)
pd.DataFrame({'Student Name': female_students}).to_csv(r'C:\Users\rehem\Downloads\cgraphics\female_students.csv', index=False)
pd.DataFrame({'Student Name': students_with_special_chars}).to_csv(r'C:\Users\rehem\Downloads\cgraphics\special_char_students.csv', index=False)
pd.DataFrame({'Student Name': list(email_records.keys()), 'Email': list(email_records.values())}).to_csv(r'C:\Users\rehem\Downloads\cgraphics\generated_emails.csv', index=False)

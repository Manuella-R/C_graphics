def is_valid_email(address):
    """
    Uses a regular expression to determine if an email address is valid.

    Args:
        address (str): The email address to be checked.

    Returns:
        bool: True if the email format is correct, False otherwise.
    """
    import re
    pattern = r"^[a-zA-Z0-9]+([\.-]?[a-zA-Z0-9]+)*@[a-zA-Z0-9]+([\.-]?[a-zA-Z0-9]+)*(\.[a-zA-Z]{2,4})+$"
    return re.search(pattern, address) is not None

def is_name_length_valid(full_name):
    """
    Verifies if the provided name length falls within the acceptable limits.

    Args:
        full_name (str): The name to validate.

    Returns:
        bool: True if the name length is valid, False otherwise.
    """
    return 3 <= len(full_name) <= 30

import re

def create_email(full_name):
    """
    Generates an email address using the first letter of the first name and the last name,
    ensuring no full stops appear between them.

    Args:
        full_name (str): The student's full name.

    Returns:
        str: A unique email address without special characters and no dots between names.
    """
    sanitized_name = re.sub(r"[^a-zA-Z\-']", "", full_name.lower())
    first_char = sanitized_name.split()[0][0]
    family_name = sanitized_name.split()[-1].replace(".", "")
    email_prefix = f"{first_char}{family_name}"

    idx = 0
    while True:
        email_id = f"{email_prefix}@gmail.com"
        if not check_email_exists(email_id):
            return email_id
        idx += 1

def check_email_exists(email_id):
    """
    Placeholder function to simulate checking if an email already exists.
    Replace with actual logic (e.g., using an API or database).

    Args:
        email_id (str): The email to verify.

    Returns:
        bool: True if the email exists, otherwise False.
    """
    return False

def is_valid_email(address):
    """
    Uses a regular expression to determine if an email address is valid.

    Args:
        address (str): The email address to be checked.

    Returns:
        bool: True if the email format is correct, False otherwise.
    """
    pattern = r"^[a-zA-Z0-9]+([\.-]?[a-zA-Z0-9]+)*@[a-zA-Z0-9]+([\.-]?[a-zA-Z0-9]+)*(\.[a-zA-Z]{2,4})+$"
    return re.search(pattern, address) is not None

def is_name_length_valid(full_name):
    """
    Verifies if the provided name length falls within the acceptable limits.

    Args:
        full_name (str): The name to validate.

    Returns:
        bool: True if the name length is valid, False otherwise.
    """
    return 3 <= len(full_name) <= 30
